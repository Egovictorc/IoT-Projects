# ESP32-Web-Server
In this project you’ll create a web server with an ESP32 that controls outputs (two LEDs) from any device using WiFi.
