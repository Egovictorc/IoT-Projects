# Shared-codes-
Codes that are linked to youtube videos and other places I have linked them for free download.
